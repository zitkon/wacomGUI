#!/bin/bash
cd "$(dirname "$0")"
vardir=$(pwd)
echo $vardir
cd $vardir
cd lib
vardir=$(pwd)
echo $vardir
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$(pwd)
echo library directory $LD_LIBRARY_PATH
cd ../
./wacom-intous-small-graphics-setting
